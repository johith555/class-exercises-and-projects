using Xunit;
using Services;
using Formatters;

namespace Solid_Assignment.Tests;

public class ReportTests
{
    [Fact]
    public void ReportGenerator_ShouldReturnExpectedContent()
    {
        var generator = new ReportGenerator();

        var result = generator.Generate();

        Assert.Equal("Report Content Generated", result);
    }

    [Fact]
    public void PdfFormatter_ShouldFormatCorrectly()
    {
        var formatter = new PdfFormatter();

        var result = formatter.Format("Test");

        Assert.Equal("PDF Format: Test", result);
    }
}