using System.Collections.Generic;

namespace RazorApp.Models
{
    public static class ItemStore
    {
        public static List<Item> Items { get; } = new List<Item>();
    }
}