using Microsoft.AspNetCore.Mvc.RazorPages;
using RazorApp.Models;
using System.Collections.Generic;

namespace RazorApp.Pages
{
    public class IndexModel : PageModel
    {
        public List<Item> Items { get; set; } = new();

        public void OnGet()
        {
            Items = ItemStore.Items;
        }
    }
}