using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RazorApp.Models;

namespace RazorApp.Pages
{
    public class AddItemModel : PageModel
    {
        [BindProperty]
        public Item NewItem { get; set; } = new();

        public IActionResult OnPost()
        {
            if (!string.IsNullOrWhiteSpace(NewItem.Name))
            {
                ItemStore.Items.Add(new Item { Name = NewItem.Name });
            }

            return RedirectToPage("Index");
        }
    }
}