document.getElementById("btn").addEventListener("click", function () {
    document.getElementById("message").innerText =
        "JavaScript is working securely with CSP!";
});