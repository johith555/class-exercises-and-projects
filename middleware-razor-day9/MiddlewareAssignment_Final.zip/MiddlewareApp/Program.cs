using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Hosting;
using System.Diagnostics;

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

 
app.UseHttpsRedirection();
 
app.Use(async (context, next) =>
{
    try
    {
        await next();
    }
    catch (Exception)
    {
        context.Response.StatusCode = 500;
        context.Response.ContentType = "text/html";
        await context.Response.WriteAsync("<h1>Something went wrong. Please try again later.</h1>");
    }
});

 
app.Use(async (context, next) =>
{
    var stopwatch = Stopwatch.StartNew();

    Console.WriteLine($"Request: {context.Request.Method} {context.Request.Path}");

    await next();

    stopwatch.Stop();

    Console.WriteLine($"Response: {context.Response.StatusCode} | Time: {stopwatch.ElapsedMilliseconds} ms");
});
 
app.Use(async (context, next) =>
{
    context.Response.Headers["Content-Security-Policy"] =
    "default-src 'self'; script-src 'self'; style-src 'self';";

    await next();
});

 
app.UseStaticFiles();

 
app.MapGet("/", () => "Middleware App Running...");

app.Run();